<?php

// don't load directly
if ( !defined('ABSPATH') )
	die('-1');

/**
 * settings page
 */
function woo_square_settings_page() {
    add_menu_page('Woo Square Settings', 'Woo-Square', 'manage_options', 'square-settings', 'square_settings_page', "dashicons-store");
    add_submenu_page('square-settings', "Square-Payment-Settings", "Square Payment", 'manage_options', 'Square-Payment-Settings', 'square_payment_plugin_page');
	
}

/**
 * Settings page action
 */
function square_settings_page() {
    $square = new Square(get_option('woo_square_access_token'), get_option('woo_square_location_id'),get_option('woo_square_app_id'));
    $errorMessage = '';
    $successMessage = '';
    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['terminate_sync'])) {
        //clear session variables if exists
        if (isset($_SESSION["square_to_woo"])){ unset($_SESSION["square_to_woo"]); };
        if (isset($_SESSION["woo_to_square"])){ unset($_SESSION["woo_to_square"]); };
        update_option('woo_square_running_sync', false);
        update_option('woo_square_running_sync_time', 0);
        Helpers::debug_log('info', "Synchronization terminated due to admin request");
        $successMessage = 'Sync terminated successfully!';
    }
    // check if the location is not setuped
    if (get_option('woo_square_access_token') && !get_option('woo_square_location_id')) {
        $square->authorize();
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // setup account
		
        if (isset($_POST['woo_square_access_token'])) {
            $square->setAccessToken(sanitize_text_field($_POST['woo_square_access_token']));
			$square->setapp_id(sanitize_text_field($_POST['woo_square_app_id']));
            if ($square->authorize()) {
                $successMessage = 'Settings updated successfully!';
            } else {
                $errorMessage = 'Square Account Not Authorized';
            }
        }
        // save settings
        if (isset($_POST['woo_square_settings'])) {
           
            
           
            //update location id
            if( !empty($_POST['woo_square_location_id'])){
                $location_id = sanitize_text_field($_POST['woo_square_location_id']);
                @$woo_square_app_id = sanitize_text_field($_POST['woo_square_app_id']);
                update_option('woo_square_location_id', $location_id);               
                $square->setLocationId($location_id);
                $square->getCurrencyCode();
               
            }

            $successMessage = 'Settings updated successfully!';
        }
    }
    $wooCurrencyCode    = get_option('woocommerce_currency');
    $squareCurrencyCode = get_option('woo_square_account_currency_code');
    
    if(!$squareCurrencyCode){
        $square->getCurrencyCode();
        $square->getapp_id();
        $squareCurrencyCode = get_option('woo_square_account_currency_code');
    }
    if ( $currencyMismatchFlag = ($wooCurrencyCode != $squareCurrencyCode) ){
        Helpers::debug_log('info', "Currency code mismatch between Square [$squareCurrencyCode] and WooCommerce [$wooCurrencyCode]");

    }
    include WOO_SQUARE_PLUGIN_PATH . 'views/settings.php';
}

/**
 * square payment plugin page action
 * @global type $wpdb
 */
function square_payment_plugin_page(){
     $square_payment_settin = get_option('woocommerce_square_settings');
 
      include WOO_SQUARE_PLUGIN_PATH . 'views/payment-settings.php';
}
/**
* Initialize Gateway Settings Form Fields
*/
	 function init_form_fields() {
	$form = array(
			'enabled' => array(
				'title'       => __( 'Enable/Disable', 'wpexpert-square' ),
				'label'       => __( 'Enable Square', 'wpexpert-square' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no'
			),
			'title' => array(
				'title'       => __( 'Title', 'wpexpert-square' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'wpexpert-square' ),
				'default'     => __( 'Credit card (Square)', 'wpexpert-square' )
			),
			'description' => array(
				'title'       => __( 'Description', 'wpexpert-square' ),
				'type'        => 'textarea',
				'description' => __( 'This controls the description which the user sees during checkout.', 'wpexpert-square' ),
				'default'     => __( 'Pay with your credit card via Square.', 'wpexpert-square')
			),
			'capture' => array(
				'title'       => __( 'Delay Capture', 'wpexpert-square' ),
				'label'       => __( 'Enable Delay Capture', 'wpexpert-square' ),
				'type'        => 'checkbox',
				'description' => __( 'When enabled, the request will only perform an Auth on the provided card. You can then later perform either a Capture or Void.', 'wpexpert-square' ),
				'default'     => 'no'
			),
			'create_customer' => array(
				'title'       => __( 'Create Customer', 'wpexpert-square' ),
				'label'       => __( 'Enable Create Customer', 'wpexpert-square' ),
				'type'        => 'checkbox',
				'description' => __( 'When enabled, processing a payment will create a customer profile on Square.', 'wpexpert-square' ),
				'default'     => 'no'
			),
			'logging' => array(
				'title'       => __( 'Logging', 'wpexpert-square' ),
				'label'       => __( 'Log debug messages', 'wpexpert-square' ),
				'type'        => 'checkbox',
				'description' => __( 'Save debug messages to the WooCommerce System Status log.', 'wpexpert-square' ),
				'default'     => 'no'
			),
			'Send_customer_info' => array(
				'title'       => __( 'Send Customer Info', 'wpexpert-square' ),
				'label'       => __( 'Send First Name Last Name', 'wpexpert-square' ),
				'type'        => 'checkbox',
				'description' => __( 'Send First Name Last Name with order to square.', 'wpexpert-square' ),
				'default'     => 'no'
			),
		);
		
		
	}
